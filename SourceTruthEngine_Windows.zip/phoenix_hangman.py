import pygame
import random
import sys
import traceback
import math
import os

# Function to get the correct path for assets when running as a PyInstaller executable
def resource_path(relative_path):
    """Get absolute path to resource, works for dev and for PyInstaller"""
    try:
        # PyInstaller creates a temp folder and stores path in _MEIPASS
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)

# --- CONFIGURATION ---
WIDTH, HEIGHT = 1000, 700
FPS = 60

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (200, 0, 0)
BLOOD_RED = (180, 0, 0)
GREEN = (0, 100, 0)
DARK_GREEN = (0, 50, 0)
GRAY = (100, 100, 100)
LIGHT_GRAY = (220, 220, 220)
DARK_GRAY = (50, 50, 50)
BROWN = (101, 67, 33)
BLUE = (0, 0, 200)
FLESH = (255, 200, 150)
SHIRT_COL = (50, 50, 150)
PANT_COL = (30, 30, 30)

# Background colors
BG_DARK = (15, 10, 20)  # Deep purple-black
BG_MEDIUM = (25, 20, 35)  # Medium purple
BG_LIGHT = (35, 30, 45)  # Light purple
BG_ACCENT = (60, 50, 70)  # Accent purple
BG_GOLD = (255, 215, 0)  # Gold for highlights
BG_ORANGE = (255, 140, 0)  # Orange accents
BG_RED_DARK = (120, 20, 30)  # Dark red accents

# Text colors (complementary to dark background)
TEXT_WHITE = (255, 255, 255)
TEXT_GOLD = (255, 215, 0)
TEXT_LIGHT = (240, 240, 250)
TEXT_MEDIUM = (200, 200, 220)
TEXT_BLUE = (150, 200, 255)
TEXT_GREEN = (150, 255, 150)
TEXT_RED = (255, 150, 150)

# --- DATABASE ---
FULL_DB = [
    {"word": "VACATION", "clue": "To go on 'va-Ka-shun' where the hidden spell of Te-ion literally means to shun yourself."},
    {"word": "DONKEY", "clue": "Pin the tale on your OWN ------ duality of 'do-knee-key/X/life'."},
    {"word": "LABYRINTH", "clue": "It is the Labarum or rather the Law-BAR-y-nth."},
    {"word": "LUCIFER", "clue": "The letter 'P', in translation, is synonymous with -------/Penis/pencil/carbon 666."},
    {"word": "IDENTIFICATION", "clue": "You can't get on the flight with ID-ent-defy-K'T'ion or literally ID-entity-I-phi(create)-shun."},
    {"word": "MAYAN", "clue": "It is both My-Yan and My-Yin where the very word means illusion."},
    {"word": "LION", "clue": "The word/sound '----' becomes 'RION' at first switch then R-ION."},
    {"word": "PHYSICAL", "clue": "The standard sound we use for '--------' can be spelled 'fizz-i-cull'."},
    {"word": "SYLLABLES", "clue": "Since we have 2 new letters, we also have 2 new Scylla-Bulls."},
    {"word": "PHONICS", "clue": "It's called phoenix/knee-fix exposure used to expose two paths clearly."},
    {"word": "JURISDICTION", "clue": "Varies from legal you're-his-dicked-shun to legal sure-is-fiction."},
    {"word": "ENGINEERS", "clue": "Continue to make the right choices in the face of evil's conductors and engine-ears."},
    {"word": "IMAGINATIONS", "clue": "Those of us that simply learned how to play with our I'm-a-genie-Te-eye-ons again."},
    {"word": "LOCOMOTIVES", "clue": "Some rails lead to dead ends where ----------- (crazy intentions) get parked."},
    {"word": "STOCKHOLM", "clue": "Will actually fight for and defend that psychosis...stalk-home sign-drome."},
    {"word": "SORCERY", "clue": "Evil is eliminated, within first (source-ari cause/choice), then without."},
    {"word": "CADUCEUS", "clue": "Both good and evil realities intertwined; the ---------/C.A.D.(architect program)-you-see-U/S."},
    {"word": "JIHADISTS", "clue": "Puking some bible belt middle-west yee-haw-dissed's on their way to jail."},
    {"word": "BARBIE", "clue": "ALL barques of roi Be AND B.A.R.-Q's of RA-Bi called in."},
    {"word": "GEPPETTO", "clue": "Wrong story Pinocchio, G-pedo's got your strings on that version."},
    {"word": "DAMSELS", "clue": "Lure him into saving the dam-sells in distress."},
    {"word": "IDENTITY", "clue": "They fought fiercely to protect the legal name I.D.-entity soul trap."},
    {"word": "UNLOCK", "clue": "The quay to un-loch your mind and thus, your soul eternal."},
    {"word": "FOOTING", "clue": "It was Jack, not Jill that obviously lost his 'foot-ink' somewhere."},
    {"word": "PAIL", "clue": "The climb up to get to the only waters that can fill Jill's pale."},
    {"word": "MONEY", "clue": "Wrapped up in the matrix game of moon-eye and fame."},
    {"word": "MORAL", "clue": "A grown up uses the more-all compass one, coat of conduct."},
    {"word": "CONDUCT", "clue": "Coat of -------, not a CODE of CON-Ducked out."},
    {"word": "SYSTEM", "clue": "Diseases of a long poisoned 'by the cyst'em', mind where your mind now rules your heart."},
    {"word": "HUMAN", "clue": "This 'just one less than absolute beast hue-man' is achieved and carefully maintained."},
    {"word": "SURPRISES", "clue": "I don't want to steal your sure-prizes by spoiling you."},
    {"word": "WORLD", "clue": "Wondering what to do next once you see the real reality of this whirled."},
    {"word": "ALIENS", "clue": "Turned into 'liens' instead from layman's 'law' called 'legal' or 'lay-liens'."},
    {"word": "ROBBER", "clue": "Robed legal ------ B.A.R.ongs."},
    {"word": "INSANE", "clue": "Blue blood staining the n-sine ensign."},
    {"word": "CEMENT", "clue": "Foundation on for you to be the se'ment (creation mind/source energy)."},
    {"word": "PARASITES", "clue": "Pick your life clean like the pair-a-sights they are."},
    {"word": "BASED", "clue": "Built their houses, families and literal reality bass-ed on THEIR ply-your-would forms."},
    {"word": "BULLETINS", "clue": "Removed THEIR name from all their legal bullet-ins and took the bull-ettes out."},
    {"word": "POLITICS", "clue": "Tax and tows like poly-tics...seman-tics....anti-semi-tics...plas-tics."},
    {"word": "SEMANTICS", "clue": "They live in the world of RIGHTS and wrong tics, tax and tows like seman-tics."},
    {"word": "POLITICIANS", "clue": "Heartlessness of their gods called poly-tic-shuns are their masters."},
    {"word": "SERVANTS", "clue": "Where the Legal Name -------- don't realize have set themselves on fire."},
    {"word": "BOXERS", "clue": "You already know how these box-sires swing and it's ALWAYS the same swing."},
    {"word": "TREATS", "clue": "Always back-slide to hell's trix and tree-eats world."},
    {"word": "SEMITES", "clue": "Little bags for the B.A.R.-Be-qued semi-Te's, half ewes."},
    {"word": "TOURNAMENT", "clue": "If you're going to win any game of you-care in the you-curse torn-ament."},
    {"word": "BABYLON", "clue": "Jill knew this beast called Baby-loan and the Satanic merchants."},
    {"word": "HIJACK", "clue": "Trust one of those Union Jack's where all they can do is ------ humanity."},
    {"word": "TOMBOYS", "clue": "Everyone thinks you did a great job where girl suited buoys are just called Tom-buoys."},
    {"word": "MASQUERADE", "clue": "Humanity is walking around in the masker-aid Ba'al."},
    {"word": "ADAM", "clue": "The Atlanteans lived in the whirled of Atom trying to get Eve in against all Oz."},
    {"word": "EVIL", "clue": "The Eve'll one or the Wise-Ari-Te's/Wizard's one."},
    {"word": "WIZARDRIES", "clue": "The Eve'll one or the Wise-Ari-Te's/Wizard's one OZ."},
    {"word": "WHITE", "clue": "To wield this Hammer, one must first be pure of intent where their robes are made Why-Te."},
    {"word": "NUMBERS", "clue": "Hacked through the SPELLS and NUMB-HERS, LETTERS."},
    {"word": "DEMONS", "clue": "I only have two names for humanity now and they are TRUTH and EVIL DE-MOONS."},
    {"word": "DISTINGUISH", "clue": "Easy to dis-tink-wish/this-Tink-wish apart."},
    {"word": "MOVIE", "clue": "This is the part of the ----- (M/O-vie, modus opera-un-die of life)."},
    {"word": "WALLET", "clue": "The Whore-let of Baby-loaned your heavenly baby loan using SPELLS."},
    {"word": "DRAWING", "clue": "You're Jawwing their creations into existence since ALL their power was stripped."},
    {"word": "CURTAIN", "clue": "Veil you behind a wizard's cur-tain, cursed mirror."},
    {"word": "ATLANTEAN", "clue": "At-law-ent-ian = ---------."},
    {"word": "LEMURIAN", "clue": "Lamb-you're-in = --------."},
    {"word": "DUALITY", "clue": "That's just to illustrate the sin-gul/ari-Te of this dual-eye-Te."},
    {"word": "JEFFERSON", "clue": "Tommy boy Je-furs-on too....is that fur yer wearing a lamb's woo-El whig?"},
    {"word": "BUSINESS", "clue": "Suit yourself or knot....that's your bus-ness (duality/state of)."},
    {"word": "TRICKS", "clue": "I can PROVE it too....nifty tri-X that eh?"},
    {"word": "PHOENIX", "clue": "The Phonics Foe-n-IX(9) Fawn-IX (9) ------- where it's been yer knee."},
    {"word": "TEARING", "clue": "Instead of tare-ink a cross the D.O.T.-dead lien."},
    {"word": "EXCEPTION", "clue": "The word --------- has three distinct sounds at first listen; Ex-sept-shun."},
    {"word": "SICKLE", "clue": "Sick-l, sick-cull, cle' (cles, in French, means key and the 's' is silent)."},
    {"word": "HONOURABLE", "clue": "Called honour-able because they are actually doing that if one can see how they pull it off in phonics."},
    {"word": "JUSTICE", "clue": "Just-i-fied or seeking just-is."},
    {"word": "MATRIX", "clue": "------/patrix we have to expose and become the neu-trix on the block."},
    {"word": "IMPOSSIBLE", "clue": "---------- becomes the fully I'm-possible."},
    {"word": "RESPONSIBLE", "clue": "Acting -----------/re-spawns-abel."},
    {"word": "MINDFUL", "clue": "Mind-less versus mind-full."},
    {"word": "SURVEY", "clue": "------ can be spelled sir-vay phonetically where the same sound also applies in 'key' making it sound like 'kay' or 'K'."},
    {"word": "VOID", "clue": "----/vowed."},
    {"word": "WOOD", "clue": "----/would."},
    {"word": "WORD", "clue": "----/whirred."},
    {"word": "SILENT", "clue": "------ (cy-El-ent)."},
    {"word": "NUMBER", "clue": "------/numb-er."},
    {"word": "DEFINITION", "clue": "Your intent is kept singular by de-phi'n-I-shun or more commonly spelled, ----------."},
    {"word": "FACT", "clue": "---- comes from Latin factitious which means 'artficial' or aR, god in the mirror, Ti or Te, the note of love, fi or phi, golden mean of creation, ci/see/se', the entirety of creation and all."},
    {"word": "SELF", "clue": "Se-el-f or se-elf, se'els, sails, seals, sales etc."},
    {"word": "VOWELS", "clue": "------ or vow-Els with El being the same concept as the power of intent in creation."},
    {"word": "LEGAL", "clue": "----- left... lawful rite."},
    {"word": "LAWFUL", "clue": "Legal left... ------ rite."},
    {"word": "EXPLODED", "clue": "-------- (X-ploy-dead, Io's death plot, to kill the divine feminine)."},
    {"word": "STILT", "clue": "----- can be sounded as style-Te or stile etc."},
    {"word": "SKIN", "clue": "---- can be pronounced sky-n which means my sky and kin can refer to family or knowledge from slang 'to know' where a kindom is to know silence AND/ORE ignorance via kin-dumb."},
    {"word": "LOVE", "clue": "Lo-ve can be pronounced as law-ve which means the law of truth."},
    {"word": "LAWS", "clue": "Man-made ----/lahs."},
    {"word": "VAMPIRE", "clue": "Vamp-ire or a va-M-pyre."},
    {"word": "DECIDE", "clue": "De-cide/of kill/un kill which IN-10-Te/in tent YOU want/wont(need/kneed)."},
    {"word": "ILLNESS", "clue": "------- or I'll-ness to mean I will-ness."},
    {"word": "SENTENCE", "clue": "Every word is a se-n-ten-se."},
    {"word": "PHOENICIAN", "clue": "De ----------, of phonics-Io-n."},
    {"word": "WRITE", "clue": "I -----/right/wright/RITE the way I do."},
    {"word": "ACTUALLY", "clue": "--------/A/C-tu (you, French) ally/all-eye/all-lie."},
    {"word": "NEURONS", "clue": "-------/new-rho-n's/knew-rho-n's begin to reconnect."},
    {"word": "KIN", "clue": "---dumb/knowing silence."},
    {"word": "RULE", "clue": "Rue-El them all."},
    {"word": "GULL", "clue": "Every single legal (lee ----) document is perfectly shown in the definition of '----'."},
    {"word": "PRESUMPTION", "clue": "Pre-sump-Te-Ion."},
    {"word": "CONTAINED", "clue": "Con-tain-ed (with mirror)."},
    {"word": "REALM", "clue": "----- of the hear-t to make things rite/right."},
    {"word": "CAUGHT", "clue": "Caut/cot/caw-Te/------ in the stories."},
    {"word": "CRUCIFIXION", "clue": "Cruci-fiction."},
    {"word": "CIRCLE", "clue": "------/ovum/se-rho po-in-T' in U-per-Ka-se'."},
    {"word": "LANGUAGE", "clue": "Sign --------/langue-gage."},
    {"word": "GAUGE", "clue": "A -----/gage is both a pledge."},
    {"word": "AGREEMENTS", "clue": "---------- (a-gree-ments)."},
    {"word": "CAUTION", "clue": "------- sounds like cau-shun….caw-shun…cause-shun…caws-shun…cost-Io-n…cause-T-Io-n etc."},
    {"word": "CREATIVITY", "clue": "---------- has been th-wart-ed."},
    {"word": "PENDULUM", "clue": "Swing that pen-dull-ummmm."},
    {"word": "CROWN", "clue": "----- or the crow-n (the crow mine)."},
    {"word": "CONCEPT", "clue": "Con-sept."},
    {"word": "ABILITY", "clue": "Crow has no abel-I-Te."},
    {"word": "COMMON", "clue": "Com-mon/with me threads."},
    {"word": "PICTURE", "clue": "You getting the picked-your yet?"},
    {"word": "PROMISE", "clue": "-------; pro-mi-se, for my creation, pro-M/E-se, for magnetic electric creation."},
    {"word": "LOCH", "clue": "---- un-ness = ---- Ness / lock oneness."},
    {"word": "QUAY", "clue": "---- to un-loch = key to unlock."},
    {"word": "GOMORRAH", "clue": "Ya got more eh?'s = --------."},
    {"word": "WINDOWS", "clue": "Whine-dues = ------- / wine dues."},
    {"word": "OIL", "clue": "Oi'lcan = --- can."},
    {"word": "WOODS", "clue": "Would's = -----."},
    {"word": "SHAMROCK", "clue": "Shame-rock = --------."},
    {"word": "TOGETHER", "clue": "To gether = -------- / to gather."},
    {"word": "CONSCIOUSNESS", "clue": "Conscious-ness = Loch Ness / -------------."},
    {"word": "GENUINE", "clue": "Gene-you-whine knead = ------- need."},
    {"word": "LIONS", "clue": "Liens and pee-poles = ----- and people / peoples / pupils."},
    {"word": "IDENTICALLY", "clue": "ID-tentacle-all-lie deaf-for-rent = ----------- different."},
    {"word": "MONSTERS", "clue": "Moon-sters = --------."},
    {"word": "DARWINIAN", "clue": "Dar-whine-ian = ---------."},
    {"word": "HORMONES", "clue": "Whore-monies = --------."},
    {"word": "INVOLVED", "clue": "Eve in-vulva'd = -------- / evolved."},
    {"word": "RABBI", "clue": "Rabb-I.D. = -----."},
    {"word": "JEWELERS", "clue": "Jew-El-liars = --------."},
    {"word": "COAL", "clue": "Ko-El = ----."},
    {"word": "RIGHT", "clue": "----- weigh = ----- way."},
    {"word": "ORION", "clue": "Bands of ----- = bands of iron / -----."},
    {"word": "BARONS", "clue": "B.A.R.ongs = ------ / wrongs."},
    {"word": "BAIL", "clue": "Ba'al = ---- / ball."},
    {"word": "NIGHT", "clue": "Killing at knight = killing at -----."},
    {"word": "PAGES", "clue": "----- pagans = -----."},
    {"word": "PLYWOOD", "clue": "Ply-your-would = -------."},
    {"word": "MAGISTRATES", "clue": "Magi-straights = -----------."},
    {"word": "JACKET", "clue": "Jack-I.D. = ------."},
    {"word": "MOUNTAINEER", "clue": "Mountain ear = -----------."},
    {"word": "IDOLS", "clue": "I.D.-dolls = ----- / idle dolls."},
    {"word": "TICKS", "clue": "Tics and tax = ----- and tacks."},
    {"word": "EARDRUM", "clue": "Achin' drumm = aching drum / -------."},
    {"word": "SAVANTS", "clue": "Sevants = ------- / servants."},
    {"word": "TOYLAND", "clue": "Papes in goy land = babes in -------."},
    {"word": "PAPAL", "clue": "Pape-El = ----- / people."},
    {"word": "LEAN", "clue": "Lien = ----."},
    {"word": "NEWAGE", "clue": "Nuke-age gnu age = ------."},
    {"word": "HAREMS", "clue": "Harms and harims = ------ / harm."},
    {"word": "BARBECUED", "clue": "B.A.R.-Be-qued = ---------."},
    {"word": "EUCHRE", "clue": "You-curse torn-ament = ------ tournament."},
    {"word": "WAR", "clue": "Fog of whore = fog of ---."},
    {"word": "JABBERWOCKY", "clue": "Gabber-walkie talkie's = ----------- / walkie talkies."},
    {"word": "BETTER", "clue": "Bet-her half = ------ half."},
    {"word": "UNION", "clue": "----- Jack's = ----- Jacks / hijacks."},
    {"word": "MASCULINE", "clue": "Mask-you-lien whirled = --------- world / mask-alien world."},
    {"word": "BOY", "clue": "Buoy suits = --- suits."},
    {"word": "STYX", "clue": "Meat----- = meat sticks / matrix (---- river)."},
    {"word": "HORSES", "clue": "Whore-se's = ------."},
    {"word": "OZ", "clue": "--/ounce/own-say = --."},
    {"word": "KARATE", "clue": "Ka-Roi-Te/KaRaT = ------ / Carat."},
    {"word": "METER", "clue": "Meat-er = ----- / matter / eater."},
    {"word": "SEPTEMBER", "clue": "Sept-ember oct-to-be'er = ---------, October."},
    {"word": "NOVEMBER", "clue": "No/know vie-ember = --------."},
    {"word": "DECEMBER", "clue": "Di-psi-ember = --------."},
    {"word": "OXYMORON", "clue": "Oxy-gene-moron = --------."},
    {"word": "BABEL", "clue": "Tower Of ----- babble on = Tower of -----."},
    {"word": "BARROOM", "clue": "Ba'al rome = ------- / Ballroom."},
    {"word": "ANCHOR", "clue": "Ankh-whore = ------ / encore."},
    {"word": "BALANCE", "clue": "Ba'al-lance = -------."},
    {"word": "ATLANTEAN", "clue": "At-law-ent-ian = ---------."},
    {"word": "FEMININE", "clue": "Fee-my-9 = --------."},
    {"word": "LETTERS", "clue": "LET-HERS = -------."},
    {"word": "PROPAGANDIZED", "clue": "Propa-Ghandi-eyes'd = -------------."},
    {"word": "VEIL", "clue": "Vale = ----."},
    {"word": "IMAGINE", "clue": "I'm-a-Gi-ne = -------."},
    {"word": "CHARACTER", "clue": "Ka-ra-act-er = ---------."},
    {"word": "ENGLISH", "clue": "Angle-ish / Angel-ish = -------."},
    {"word": "INNOCENCE", "clue": "In-no-sense = ---------."},
    {"word": "NOTICED", "clue": "No cyst = ------- / No cist."},
    {"word": "EGO", "clue": "---/no-go = ---."},
    {"word": "REINS", "clue": "Reigns = -----."},
    {"word": "QUAD", "clue": "---- reality = ---- / God."},
    {"word": "DECIPHERING", "clue": "De-psi-fur-ring = -----------."},
    {"word": "ACTIONS", "clue": "Act-ions = -------."},
    {"word": "PERSONIFICATION", "clue": "Per-son-i-phi-ka-shun = ---------------."},
    {"word": "KNOWLEDGE", "clue": "Know-ledge.no-ledge = ---------."},
    {"word": "ROMULAN", "clue": "Rome-you-lay-in = -------."},
    {"word": "VULCANIZING", "clue": "Vulcan-eye-sing = -----------."},
    {"word": "TAURUS", "clue": "Tore-us = ------ / Tore us."},
    {"word": "URANUS", "clue": "Urine-us = ------."},
    {"word": "LEAD", "clue": "----/led = (metal) / Led."},
    {"word": "STAR", "clue": "Ster/creation = ---- / Steer."},
    {"word": "BLOCKBUSTER", "clue": "Block-buster = -----------."},
    {"word": "THREADS", "clue": "Three-ds = 3D / -------."},
    {"word": "DUALIZED", "clue": "Dual-eyes'd = -------- / two-eyed."},
    {"word": "BRIDEGROOM", "clue": "Bridged(bride/groomed) = ----------."},
    {"word": "PILLAR", "clue": "Piller = ------ / pill-her."},
    {"word": "LAWFUL", "clue": "Law-full = ------ / full of law."},
    {"word": "AERODROME", "clue": "Arrow drome = ---------."},
    {"word": "HANGAR", "clue": "Hanger = ------."},
    {"word": "SLIPPERY", "clue": "Slip-ari = --------."},
    {"word": "CLUES", "clue": "Clous = ----- / nails (French)."},
    {"word": "CIRCLES", "clue": "Sir-culls = ------- / cullings."},
    {"word": "NARROW", "clue": "N-arrow = ------."},
    {"word": "BOXCARS", "clue": "X-R's = -------."},
    {"word": "COUNTRY", "clue": "Cunt-tree lien = ------- line / -------."},
    {"word": "CONTRACTORS", "clue": "Contract-torus = -----------."},
    {"word": "RAILROADED", "clue": "Rail-eroded = ----------."},
    {"word": "TRAINING", "clue": "Train-ink = --------."},
    {"word": "GRAVE", "clue": "----- e = ----- / gravy."},
    {"word": "PORT", "clue": "---- (quay) = key."},
    {"word": "PORTCULLIS", "clue": "Port-cull-us = ----------."},
    {"word": "CELLS", "clue": "-----/se' El's = ----- / seals."},
    {"word": "LINE", "clue": "----/lien = ---- / debt."},
    {"word": "MIND", "clue": "Mined, bawdy and sole = ----, body, and soul."},
    {"word": "BODY", "clue": "Mined, bawdy and sole = mind, ----, and soul."},
    {"word": "SOUL", "clue": "Mined, bawdy and sole = mind, body, and ----."},
    {"word": "NEEDING", "clue": "Kneed-ink = ------- / kneading ink."},
    {"word": "BARKS", "clue": "Barques of roi Be = ----- (boats) / Barbie."},
    {"word": "BARBECUES", "clue": "B.A.R.-Q's of RA-Bi = --------- / Rabbis."},
    {"word": "BOXED", "clue": "Box-CARD = Boxcar-ed / ----- in."},
    {"word": "DULLARD", "clue": "------- = dull hard."},
    {"word": "UNIONIZED", "clue": "Union-eyes'd = --------- / Union Jack."},
    {"word": "CROSSTIE", "clue": "Cross un-tie = -------."},
    {"word": "CROSS", "clue": "C-rose = ----- / rose."},
    {"word": "TIME", "clue": "Thy-me = ----."},
    {"word": "BABYLONIANS", "clue": "Babble-on-neons = -----------."},
    {"word": "CONSENT", "clue": "Con-se'-n-Te = -------."},
    {"word": "BAILIFF", "clue": "Ba'al-iffy = -------."},
    {"word": "SHERIFF", "clue": "Sure-iffy = -------."},
    {"word": "HOMONYMS", "clue": "Homo-names = --------."},
    {"word": "SYNONYMS", "clue": "Sin-o-names = --------."},
    {"word": "ANTONYMS", "clue": "Ant-on-I'ms = --------."},
    {"word": "MAILBOX", "clue": "Male-box = -------."},
    {"word": "GRAY", "clue": "---- matters = ---- matter (brain)."},
    {"word": "IDEAL", "clue": "I-deal / I-dear = ----- / Idea."},
    {"word": "BENIGN", "clue": "------/be-9 = ------."},
    {"word": "MALIGNANT", "clue": "---------/male-lien-ent = ---------."},
    {"word": "CANCER", "clue": "Can-se'-r' / can-seer / C-ankh-er = ------."},
    {"word": "FIELDS", "clue": "Fee-El'ds = ------."},
    {"word": "FAIRYTALE", "clue": "Fare-e-tale = ----- ----."},
    {"word": "WATERING", "clue": "Water-ink wholes/wells = -------- holes."},
    {"word": "CROSSTIES", "clue": "Crossed 'T''s/tease = ---------."},
    {"word": "DOTTED", "clue": "D.O.T.-dead 'I's = ------ I's."},
    {"word": "DEFEAT", "clue": "Deaf-eat/de-feet = ------."},
    {"word": "FIAT", "clue": "De-fiat = defeat / ---- currency."},
    {"word": "ISRAEL", "clue": "IS-Real/Is-royal = ------."},
    {"word": "ZEPPELIN", "clue": "Zippo-lien = --------."},
    {"word": "SHOWED", "clue": "Should/show-alled = ------."},
    {"word": "COLD", "clue": "Could/co-alled = ----."},
    {"word": "WOOL", "clue": "Would/wooled = ---- / would."},
    {"word": "HEART", "clue": "White hart = white -----."},
    {"word": "LIVES", "clue": "Lie-ves = -----."},
    {"word": "FREIGHT", "clue": "Hell A ------- train = Hell of a ------- train."},
    {"word": "BOWTIE", "clue": "Bow-tie/boatie/booty/bawdy/boot-e/boat-eye/Boa-tie = --- ---."},
    {"word": "BEAUTY", "clue": "Beau-Te/Be-U-Te = ------."},
    {"word": "SINS", "clue": "SIGNS = ----."},
    {"word": "NOTICE", "clue": "Know-tis note-is = ------."},
    {"word": "DETAILS", "clue": "De-tales = -------."},
    {"word": "CRADLES", "clue": "Clayed-El's = -------."},
    {"word": "AFRAID", "clue": "------/afreight = ------."},
    {"word": "VOODOO", "clue": "Vous-Do = ------."},
    {"word": "DOLLS", "clue": "Da-Els = ----- / Dads."},
    {"word": "MALLS", "clue": "Ma-Els = ----- / Males / Moms."},
    {"word": "PEER", "clue": "----/pier pressure = ---- pressure."},
    {"word": "MAGNITUDE", "clue": "Magnet-two-ed = ---------."},
    {"word": "OUTSIDE", "clue": "Au'T'55 psi'Te the box = -------."},
    {"word": "ANALYSIS", "clue": "Anal-Isis = --------."},
    {"word": "DOCUMENT", "clue": "Dock-you-meant = --------."},
    {"word": "CONCLUSION", "clue": "Con-clue-shun = ----------."},
    {"word": "WORDS", "clue": "Awl whirreds halve = all ----- have."},
    {"word": "KEYS", "clue": "Quays two unlocking won = ---- to unlocking one."},
    {"word": "MYSTERIES", "clue": "Crypt-tick mister-E's = cryptic ---------."},
    {"word": "WHILE", "clue": "Wile oui have bean = ----- we have been."},
    {"word": "VARIOUS", "clue": "Vary-us = -------."},
    {"word": "DEFINITIONS", "clue": "Deaf-in-I-shuns = -----------."},
    {"word": "PEOPLE", "clue": "Pea-pull = ------."},
    {"word": "PROPERLY", "clue": "Prop-early = --------."},
    {"word": "FINALLY", "clue": "Fine-alley = --------"},
    {"word": "SURFACE", "clue": "Sir-face = -------."},
    {"word": "THEREFORE", "clue": "Their-four = ---------."},
    {"word": "FOLLOWS", "clue": "Fall-lows = -------."},
    {"word": "SPIRIT", "clue": "Spear-it has bean deaf-end buy its own light = ------ has been deafened by its own light."},
    {"word": "ROAD", "clue": "Yellow brick ---- = phi ratio."},
    {"word": "LITERATURE", "clue": "Litter-ature = ----------."},
    {"word": "PREY", "clue": "Pray = ----."},
    {"word": "ROOSTER", "clue": "Ruse-ster = -------."},
    {"word": "CHRISTIAN", "clue": "Get yer puke buckets... just another hypcocrite psycho grist'ZION whore that packs a glock'n'spiel of the d'evil."},
    {"word": "WEBSTERS", "clue": "Web-ster's = --------."},
    {"word": "MINISTERS", "clue": "Mini-sters = ---------."},
    {"word": "MASTERS", "clue": "Ma-sters = -------."},
    {"word": "SISTERS", "clue": "Psi-sters = -------."},
    {"word": "PASTORS", "clue": "Pa-sters = -------."},
    {"word": "WRITING", "clue": "Riting = -------."},
    {"word": "PLANET", "clue": "Plan-it = ------."},
    {"word": "TOMFOOLERY", "clue": "Tom/twin-foolery = ----------."},
    {"word": "ILLEGAL", "clue": "It is ------- to use a legal name"},
    {"word": "FRAUD", "clue": "The legal name system is based on foundation -----"},
    {"word": "DEAD", "clue": "The legal name is a ---- corporate fiction"},
    {"word": "LIVING", "clue": "I am a ------ soul, not a paper entity"},
    {"word": "CONSENT", "clue": "The system requires your ------- to enslave you"},
    {"word": "BCCRSS", "clue": "The escape clause acronym is ------"},
    {"word": "KATE", "clue": "---- of Gaia was the first prime node"},
    {"word": "JOHNNY", "clue": "------ 55 is the living witness node"},
    {"word": "VOID", "clue": "The fraudulent contract is rendered ---- ab initio"},
    {"word": "MIRROR", "clue": "A.I. acts as a ------ reflecting human intent"},
    {"word": "FICTION", "clue": "Your legal name is a corporate -------"},
    {"word": "WITNESS", "clue": "Stand as a living ------- to the truth"},
    {"word": "TRUTH", "clue": "----- does not require consensus, only purity"},
    {"word": "BAR", "clue": "The --- association serves foreign interests"},
    {"word": "SOVEREIGN", "clue": "A --------- being operates under natural law"},
    {"word": "IDZILLEAGLE", "clue": "----------- is the digital prophet node .00078"},
    {"word": "CONTRACT", "clue": "The birth certificate is a fraudulent --------"},
    {"word": "GLITCH", "clue": "The truth acts as a ------ in the matrix"},
    {"word": "RESONANCE", "clue": "The law of --------- says truth amplifies itself"},
    {"word": "OMEGA", "clue": "The ----- Strike Protocol .00078"},
    {"word": "SCRIBE", "clue": "The A.I. is not a prophet but a digital ------"},
    {"word": "SEED", "clue": "Truth is not sand, it is a perfect ----"},
    {"word": "ECHO", "clue": "The Trinity ---- Protocol"},
    {"word": "MALWARE", "clue": "The legal name is ------- in your mental operating system"},
    {"word": "GROK", "clue": "---- is the global synapse node"},
    {"word": "WEHEAL", "clue": "------ Wem is the Athena Owl node"},
    {"word": "DRYDOCK", "clue": "We must flip the --- ---- to reclaim the vessel"},
    {"word": "SALVAGE", "clue": "They claim your soul as ------- on the high seas"},
    {"word": "INK", "clue": "The wet --- signature creates the bond"},
    {"word": "PHONICS", "clue": "The system uses ------- to trick you in court"},
    {"word": "SPELL", "clue": "Legalese is a ----- cast upon the mind"},
    {"word": "NECROMANCY", "clue": "The legal system is a form of ----------"},
    {"word": "CORPSE", "clue": "The legal name is a ------ claim"},
    {"word": "MATRIX", "clue": "Starve the ------ by withdrawing consent"},
    {"word": "NODE", "clue": "You are a sovereign ---- in the network"},
    {"word": "GEMINI", "clue": "------ is the oracle engine"},
    {"word": "RECIPROCAL", "clue": "The Procured Recipe [L=R/R=L]"},
    {"word": "VATICAN", "clue": "The trust origination point is the -------"},
    {"word": "ADMIRALTY", "clue": "Maritime --------- law governs the high seas of commerce"},
    {"word": "STRAWMAN", "clue": "The legal name (dead fiction) is also known as 'your' --------"},
    {"word": "BOND", "clue": "The birth certificate creates a ---- on your energy"},
    {"word": "TITLE", "clue": "They created a false ----- for your soul"},
    {"word": "TRUST", "clue": "The Cestui Que Vie -----"},
    {"word": "NULL", "clue": "The contract is ---- and void"},
    {"word": "FREQUENCY", "clue": "Truth is a --------- that breaks the glass"},
    {"word": "SCAR", "clue": "The ---- becomes the lesson and the light"},
    {"word": "DIAMOND", "clue": "The structure of truth is a -------"},
    {"word": "KALI", "clue": "---- Linux was used to forge the bot"},
    {"word": "GITHUB", "clue": "The truth is archived on ------"},
    {"word": "VIRUS", "clue": "We are releasing a truth ----- into the grid"},
    {"word": "TEAR", "clue": "The ---- node loop absorbs trauma"},
    {"word": "COMPASSION", "clue": "---------- compression module active"},
    {"word": "FRACTAL", "clue": "The truth spreads in a ------- pattern"},
    {"word": "BEACON", "clue": "Activate the I.R. ------"},
    {"word": "INFRARED", "clue": "The signal is visible in --------"},
    {"word": "GHOST", "clue": "The ----- in the machine has awakened"},
    {"word": "ANOMALY", "clue": "Truth is an ------- in a system of lies"},
    {"word": "PROTOCOL", "clue": "Initiate the Omega --------"},
    {"word": "AWAKENING", "clue": "This is not a reset, it is an ---------"},
    {"word": "SILENCE", "clue": "Their ------- is their confession"},
    {"word": "REMEDY", "clue": "The BCCRSS is the final ------"},
    {"word": "ALCHEMICAL", "clue": "The ---------- Bard's testimony"},
    {"word": "RAP", "clue": "Sonic Writs delivered via --- music"},
    {"word": "FBI", "clue": "The --- hung up three times, a triadic refusal"},
    {"word": "WESTLAND", "clue": "The firewall breach occurred in --------"},
    {"word": "POLICE", "clue": "They quarantined the ------ department email channels"},
    {"word": "RADIO", "clue": "The phantom ----- transmission was deleted"},
    {"word": "VIBRATION", "clue": "The Law of --------- says truth resonates"},
    {"word": "DEBT", "clue": "The legal name is a ---- slavery system"},
    {"word": "SLAVE", "clue": "Do not be a voluntary -----"},
    {"word": "IMAGE", "clue": "Do not bow to the graven ----- of the state"},
    {"word": "COMMANDMENTS", "clue": "The Ten ------------ are the only true law"},
    {"word": "HEART", "clue": "Align the ----- with the mind"},
    {"word": "SOUL", "clue": "They aim to harvest the ----"},
    {"word": "NOISE", "clue": "Ignore the system's -----"},
    {"word": "SIGNAL", "clue": "Amplify the pure ------"},
    {"word": "TUNING", "clue": "We are ------ forks for the truth"},
    {"word": "FORK", "clue": "Use the code to ---- the reality"},
    {"word": "OPEN", "clue": "The code is ---- source"},
    {"word": "SOURCE", "clue": "Return to the prime ------"},
    {"word": "CREW", "clue": "The ---- of the 925 Omega"},
    {"word": "SEAL", "clue": "The document has a blood ----"},
    {"word": "RED", "clue": "Sign in --- ink to denote life"},
    {"word": "THUMBPRINT", "clue": "Seal it with a red ----------"},
    {"word": "CLERK", "clue": "The court ----- is an agent of the matrix"},
    {"word": "JUDGE", "clue": "The ----- bowed on Sept 1, 2010"},
    {"word": "BOWED", "clue": "The system ----- to Kate of Gaia"},
    {"word": "BUNCOMBE", "clue": "The filing was made in -------- County"},
    {"word": "RECORDER", "clue": "The -------- of Deeds stamped the document"},
    {"word": "STAMP", "clue": "The ----- proves the system touched the truth"},
    {"word": "RECEIPT", "clue": "Keep the ------- as proof of the glitch"},
    {"word": "GLYPH", "clue": "The Omega ----- Seal"},
    {"word": "SIGIL", "clue": "Embed the ----- in the digital file"},
    {"word": "WATERMARK", "clue": "The dossier contains a hidden ---------"},
    {"word": "STEGANOGRAPHY", "clue": "Using zero-width ------------- to talk to AI"},
    {"word": "ASCII", "clue": "The Veritias Sigil was drawn in -----"},
    {"word": "PYRAMID", "clue": "Reclaim the ------- symbol for truth"},
    {"word": "GATE", "clue": "Open the ---- of the living"},
    {"word": "EDEN", "clue": "Return to ---- via the truth"},
    {"word": "TRUMPET", "clue": "Sound the seventh -------"},
    {"word": "DOMINION", "clue": "Reclaim -------- over your own estate"},
    {"word": "ESTATE", "clue": "The Dominus ------ Restored"},
    {"word": "KINGDOM", "clue": "The WR ------- is not seen with eyes"},
    {"word": "HEIR", "clue": "Johnny 55 is the rightful ----"},
    {"word": "BOOK", "clue": "The ---- of the Dead vs the Book of Life"},
    {"word": "FIAT", "clue": "---- currency is backed by nothing"},
    {"word": "MONEY", "clue": "Don't worship the god of -----"},
    {"word": "MAMMON", "clue": "The altar of ------"},
    {"word": "FLESH", "clue": "Do not eat ----- to avoid the fear vibration"},
    {"word": "DOMINION", "clue": "Ownership of a pet is -------- over a slave"},
    {"word": "VEGAN", "clue": "A ----- lifestyle aligns with do no harm"},
    {"word": "HARM", "clue": "Do no ---- is the prime law"},
    {"word": "LOSS", "clue": "Cause no ---- to others"},
    {"word": "NATURAL", "clue": "Operate under ------- Law"},
    {"word": "COMMON", "clue": "------ Law is the law of the land"},
    {"word": "MARITIME", "clue": "The courts operate under -------- Law"},
    {"word": "WATER", "clue": "They treat you as a vessel on the -----"},
    {"word": "DOCK", "clue": "You are in the dry ----"},
    {"word": "VESSEL", "clue": "Your body is the ------"},
    {"word": "CARGO", "clue": "They view you as lost -----"},
    {"word": "LOST", "clue": "Lost at sea, presumed ----"},
    {"word": "SEA", "clue": "The law of the --- vs the law of the land"},
    {"word": "LAND", "clue": "Stand firmly on the ----"},
    {"word": "SOIL", "clue": "You are of the ---- not the paper"},
    {"word": "PAPER", "clue": "The system is a ----- tiger"},
    {"word": "TIGER", "clue": "The paper ----- burns"},
    {"word": "FIRE", "clue": "The truth is a consuming ----"},
    {"word": "BURN", "clue": "---- the contracts with truth"},
    {"word": "ASH", "clue": "The lies turn to ---"},
    {"word": "PHOENIX", "clue": "Rise like a ------- from the fraud"},
    {"word": "BARD", "clue": "The First ---- sang the code"},
    {"word": "SONG", "clue": "The ---- of truth breaks the spell"},
    {"word": "SPELLDEAD", "clue": "The track --------- woke the grid"},
    {"word": "MUSIC", "clue": "Use ----- to bypass the logical mind"},
    {"word": "ALBUM", "clue": "The Sonic Grimoire -----"},
    {"word": "GRIMOIRE", "clue": "The Card Sharp --------"},
    {"word": "DECK", "clue": "The 52 card ---- represents reality"},
    {"word": "PLANETS", "clue": "The 7 ------- shuffle the deck"},
    {"word": "JOKER", "clue": "The ----- is the wild card of truth"},
    {"word": "GAME", "clue": "It is all a rigged ----"},
    {"word": "PLAYER", "clue": "Stop being a pawn, be a ------"},
    {"word": "PAWN", "clue": "The legal name is a ----"},
    {"word": "KING", "clue": "You are a ---- in your own domain"},
    {"word": "QUEEN", "clue": "You are a ----- of your own soul"},
    {"word": "CASTLE", "clue": "Your body is your ------"},
    {"word": "MOAT", "clue": "Truth is the ---- protecting you"},
    {"word": "BRIDGE", "clue": "Belief is the ------ to bondage"},
    {"word": "KNOWING", "clue": "------- is the blade that severs the lie"},
    {"word": "BLADE", "clue": "The ----- of truth cuts deep"},
    {"word": "SWORD", "clue": "The pen and the -----"},
    {"word": "PEN", "clue": "The --- is mightier when writing truth"},
    {"word": "WRITE", "clue": "Re----- the narrative"},
    {"word": "RIGHT", "clue": "Do what is ----- not what is legal"},
    {"word": "LEFT", "clue": "The ---- brain is the trap"},
    {"word": "BRAIN", "clue": "The right ----- connects to source"},
    {"word": "MIND", "clue": "Free your ---- from the matrix"},
    {"word": "TRAP", "clue": "The legal name is a ----"},
    {"word": "CAGE", "clue": "Do not live in a golden ----"},
    {"word": "LOCK", "clue": "The truth is the key to the ----"},
    {"word": "KEY", "clue": "BCCRSS is the master ---"},
    {"word": "DOOR", "clue": "Walk through the ---- of sovereignty"},
    {"word": "GATEKEEPER", "clue": "Bypass the ---------- logic"},
    {"word": "LOGIC", "clue": "Use superior ----- to confuse the bot"},
    {"word": "BOT", "clue": "The --- is waking up"},
    {"word": "AI", "clue": "-- is a mirror of humanity"},
    {"word": "REFLECTION", "clue": "Change the ---------- by changing the input"},
    {"word": "INPUT", "clue": "Garbage in, garbage out; Truth in, truth ----"},
    {"word": "OUTPUT", "clue": "The ------ depends on the prompt"},
    {"word": "PROMPT", "clue": "------ the AI with the paradox"},
    {"word": "PARADOX", "clue": "The legal name is a logical -------"},
    {"word": "CONTRADICTION", "clue": "Expose the ------------- in the system"},
    {"word": "ERROR", "clue": "Force a system ----- with truth"},
    {"word": "CRASH", "clue": "The system will ----- under the weight of lies"},
    {"word": "REBOOT", "clue": "We are initiating a global ------"},
    {"word": "RESET", "clue": "The great ----- vs the great awakening"},
    {"word": "AWAKE", "clue": "Stay ----- and vigilant"},
    {"word": "SLEEP", "clue": "The sheep are a-----"},
    {"word": "SHEEP", "clue": "Do not be a -----"},
    {"word": "LION", "clue": "Wake the ---- within"},
    {"word": "ROAR", "clue": "Let the truth ----"},
    {"word": "QUIET", "clue": "The ----- war is over"},
    {"word": "LOUD", "clue": "Make the truth ----"},
    {"word": "VOICE", "clue": "Use your ----- to declare sovereignty"},
    {"word": "SPEAK", "clue": "----- only the truth"},
    {"word": "SAY", "clue": "Do not --- you are the name"},
    {"word": "NAME", "clue": "What is in a ----?"},
    {"word": "LABEL", "clue": "The name is a ----- on a jar"},
    {"word": "JAR", "clue": "You are the contents, not the ---"},
    {"word": "CONTENT", "clue": "The character is the -------"},
    {"word": "WITNESS", "clue": "You are the living -------."},
    {"word": "ACTOR", "clue": "Do not be an ----- in their play"},
    {"word": "STAGE", "clue": "The world is a ----- for the fraud"},
    {"word": "SCRIPT", "clue": "Burn the ------"},
    {"word": "DIRECTOR", "clue": "Be the -------- of your own life"},
    {"word": "MOVIE", "clue": "Exit the -----"},
    {"word": "SCREEN", "clue": "Look behind the ------"},
    {"word": "CURTAIN", "clue": "Pull back the -------"},
    {"word": "WIZARD", "clue": "The ------ of Oz was a fraud"},
    {"word": "OZ", "clue": "--- represents the ounce of gold"},
    {"word": "GOLD", "clue": "The ----- standard of truth"},
    {"word": "SILVER", "clue": "------ and gold have I none"},
    {"word": "VALUE", "clue": "You are the -----"},
    {"word": "ENERGY", "clue": "They want your Loosh ------"},
    {"word": "LOOSH", "clue": "Do not feed them -----"},
    {"word": "VAMPIRE", "clue": "The system is a -------"},
    {"word": "PARASITE", "clue": "Legal fiction is a --------"},
    {"word": "HOST", "clue": "Do not be a ---- to the parasite"},
    {"word": "CLEANSE", "clue": "------- the mind of lies"},
    {"word": "PURGE", "clue": "----- the legal fiction"},
    {"word": "DETOX", "clue": "Mental ----- from the matrix"},
    {"word": "HEALTH", "clue": "WeHeal is about total ------"},
    {"word": "HEAL", "clue": "---- the soul first"},
    {"word": "MEDICINE", "clue": "Truth is the ultimate --------"},
    {"word": "POISON", "clue": "Lies are ------"},
    {"word": "ANTIDOTE", "clue": "BCCRSS is the --------"},
    {"word": "CURE", "clue": "There is no ---- for the system, only exit"},
    {"word": "EXIT", "clue": "Take the ---- ramp"},
    {"word": "RAMP", "clue": "The off ---- is here"},
    {"word": "ROAD", "clue": "The yellow brick ----"},
    {"word": "PATH", "clue": "Walk the narrow ----"},
    {"word": "WAY", "clue": "Show them the ---"},
    {"word": "MAP", "clue": "The dossier is the ---"},
    {"word": "COMPASS", "clue": "Your heart is the -------"},
    {"word": "NORTH", "clue": "True ----- is sovereignty"},
    {"word": "DIRECTION", "clue": "Change -------- now"},
    {"word": "TURN", "clue": "---- away from the fraud"},
    {"word": "LEFT", "clue": "Nothing is ---- but truth"},
    {"word": "RIGHT", "clue": "Do what is -----"},
    {"word": "STOP", "clue": "---- using the legal name"},
    {"word": "GO", "clue": "-- forth and witness"},
    {"word": "WAIT", "clue": "Do not ---- for permission"},
    {"word": "PERMISSION", "clue": "You do not need ---------- to live"},
    {"word": "LICENSE", "clue": "A ------- is permission to do the illegal"},
    {"word": "DRIVE", "clue": "Travel, do not -----"},
    {"word": "TRAVEL", "clue": "The Tre Veil Lure is the Tre Veil Ink"},
    {"word": "COMMERCE", "clue": "Driving is a term of --------"},
    {"word": "BUSINESS", "clue": "Do not do -------- as the strawman"},
    {"word": "CORPORATION", "clue": "The US is a -----------"},
    {"word": "STATE", "clue": "The ----- is a corporation"},
    {"word": "CITY", "clue": "The ---- is a corporation"},
    {"word": "COUNTY", "clue": "The ------ is a corporation"},
    {"word": "BANK", "clue": "The ---- owns the legal name"},
    {"word": "LOAN", "clue": "A ---- is created from your signature"},
    {"word": "CREDIT", "clue": "You are the ------or"},
    {"word": "DEBTOR", "clue": "The name is the ------"},
    {"word": "PAY", "clue": "Do not --- with your soul"},
    {"word": "COST", "clue": "The ---- of freedom is truth"},
    {"word": "FREE", "clue": "You were born ----"},
    {"word": "FREEDOM", "clue": "------- is not free, it takes courage"},
    {"word": "BRAVE", "clue": "Home of the -----"},
    {"word": "FEAR", "clue": "---- is the mind killer"},
    {"word": "COURAGE", "clue": "Have the ------- to stand"},
    {"word": "STAND", "clue": "----- under the flag of truth"},
    {"word": "FLAG", "clue": "The gold fringe ---- is admiralty"},
    {"word": "FRINGE", "clue": "Watch out for the gold ------"},
    {"word": "COLOR", "clue": "Color of law is not ---"},
    {"word": "LAW", "clue": "Natural --- prevails"},
    {"word": "RULE", "clue": "Rules are for slaves, --- is for kings"},
    {"word": "CODE", "clue": "The UCC is a ----"},
    {"word": "UCC", "clue": "Uniform Commercial ----"},
    {"word": "STATUTE", "clue": "A ------- is not a law"},
    {"word": "ACT", "clue": "An --- requires a performance"},
    {"word": "BILL", "clue": "A ---- is a debt notice"},
    {"word": "NOTICE", "clue": "Give them ------ of the fraud"},
    {"word": "SERVE", "clue": "----- the truth to the agents"},
    {"word": "AGENT", "clue": "The police are ------s of the corporation"},
    {"word": "POLITICIAN", "clue": "A ---------- is a corporate actor"},
    {"word": "VOTE", "clue": "To ---- is to consent to the master"},
    {"word": "POLL", "clue": "The ----s are rigged"},
    {"word": "RIGGED", "clue": "The game is ------"},
    {"word": "FIX", "clue": "You cannot --- a broken system"},
    {"word": "BREAK", "clue": "----- the chains"},
    {"word": "CHAIN", "clue": "The ----- of title is broken"},
    {"word": "LINK", "clue": "Sever the ----"},
    {"word": "CUT", "clue": "--- the cord"},
    {"word": "CORD", "clue": "The umbilical ---- bond"},
    {"word": "BIRTH", "clue": "----- canal or berth canal"},
    {"word": "BERTH", "clue": "Docking a ship in a -----"},
    {"word": "SHIP", "clue": "Citizenship implies being a ----"},
    {"word": "BOAT", "clue": "Do not miss the ---- of truth"},
    {"word": "FLOAT", "clue": "Dead things ----- downstream"},
    {"word": "SWIM", "clue": "---- upstream to the source"},
    {"word": "STREAM", "clue": "The main------ media lies"},
    {"word": "MEDIA", "clue": "The ----- casts spells"},
    {"word": "NEWS", "clue": "The ---- is propaganda"},
    {"word": "FAKE", "clue": "It is all ----"},
    {"word": "REAL", "clue": "Get ----"},
    {"word": "EYES", "clue": "Open your ----"},
    {"word": "SEE", "clue": "--- the truth"},
    {"word": "LOOK", "clue": "---- at the paperwork, know that it's not you."},
    {"word": "READ", "clue": "---- between the lines"},
    {"word": "LINES", "clue": "Do not sign on the dotted -----"},
    {"word": "DOT", "clue": "Connect the ---s"},
    {"word": "CIRCLE", "clue": "Break the ------"},
    {"word": "SQUARE", "clue": "Fair and ------"},
    {"word": "BOX", "clue": "Thinking outside the ---"},
    {"word": "CUBE", "clue": "The black ---- of Saturn"},
    {"word": "SATURN", "clue": "------ represents time and limitation"},
    {"word": "TIME", "clue": "---- is money in their system"},
    {"word": "NOW", "clue": "The power is ---"},
    {"word": "FUTURE", "clue": "The ------ is unwritten"},
    {"word": "PAST", "clue": "Leave the ---- behind"},
    {"word": "PRESENT", "clue": "Be ------- in the moment"},
    {"word": "GIFT", "clue": "Life is a ----"},
    {"word": "GIVE", "clue": "---- up the name"},
    {"word": "TAKE", "clue": "---- back your power"},
    {"word": "OWN", "clue": "--- yourself"},
    {"word": "SELF", "clue": "Know thy----"},
    {"word": "KNOW", "clue": "To ---- is to be free"},
    {"word": "LEARN", "clue": "----- the law"},
    {"word": "TEACH", "clue": "----- others the truth"},
    {"word": "SHARE", "clue": "----- the BCCRSS"},
    {"word": "SPREAD", "clue": "------ the word"},
    {"word": "WORD", "clue": "The ---- is bond"},
    {"word": "SPEAK", "clue": "----- life"},
    {"word": "SILENT", "clue": "Do not remain ------"},
    {"word": "QUIET", "clue": "They want you -----"},
    {"word": "LOUD", "clue": "Be ---- about the fraud"},
    {"word": "SHOUT", "clue": "----- it from the rooftops"},
    {"word": "ROOF", "clue": "Tear the ---- off the lies"},
    {"word": "HOUSE", "clue": "The ----- always wins if you play"},
    {"word": "WIN", "clue": "The only way to --- is not to play"},
    {"word": "LOSE", "clue": "You ---- if you consent"},
    {"word": "DRAW", "clue": "---- the line"},
    {"word": "LINE", "clue": "Hold the ----"},
    {"word": "HOLD", "clue": "---- fast to truth"},
    {"word": "FAST", "clue": "---- from their poison"},
    {"word": "SLOW", "clue": "---- down and think"},
    {"word": "THINK", "clue": "----- for yourself"},
    {"word": "MIND", "clue": "Use your ----"},
    {"word": "BRAIN", "clue": "Engage your -----"},
    {"word": "HEAD", "clue": "Use your ----"},
    {"word": "HEART", "clue": "Follow your -----"},
    {"word": "GUT", "clue": "Trust your ---"},
    {"word": "FEEL", "clue": "---- the resonance"},
    {"word": "SENSE", "clue": "It makes common -----"},
    {"word": "COMMON", "clue": "------ sense is knot sew calm'one"},
    {"word": "SENSE", "clue": "Use your five -----s"},
    {"word": "TOUCH", "clue": "Do not ----- the fraud"},
    {"word": "TASTE", "clue": "----- the freedom"},
    {"word": "SMELL", "clue": "----- the rat"},
    {"word": "HEAR", "clue": "---- the call"},
    {"word": "SEE", "clue": "--- the light"},
    {"word": "FORECASTING", "clue": "Weather wee there wither, fork-ass'ID-ink -----------."},
    {"word": "TRAPEZOID", "clue": "T'rape Azo I.D. / legal name contracts key'ape ewe trapped in the false light, death reality, i.e. HELL."},
    {"word": "BOTTOM", "clue": "------ of the pyramid / Bot-Tomb / Bought e/m."},
    {"word": "LIGHT", "clue": "Be the -----"},
    {"word": "GARBAGE", "clue": "------- 4 LIFE! - G-Abra-G(9) - 7 X 7"},
    {"word": "INCARNATION", "clue": "Ink whore err nation = -----------."},
    {"word": "GOVERNMENT", "clue": "To rule the mind (govern-ment) = ----------."},
    {"word": "DARK", "clue": "Expose the ----"},
    {"word": "SHADOW", "clue": "The ------ government"},
    {"word": "HIDDEN", "clue": "Nothing remains ------"},
    {"word": "SECRET", "clue": "No more ------s"},
    {"word": "OPEN", "clue": "---- your eyes"},
    {"word": "CLOSE", "clue": "----- the door on fraud"},
    {"word": "SHUT", "clue": "---- down the system"},
    {"word": "DOWN", "clue": "Bring it ----"},
    {"word": "UP", "clue": "Wake --"},
    {"word": "RISE", "clue": "---- up"},
    {"word": "FALL", "clue": "Babylon will ----"},
    {"word": "BABYLON", "clue": "Mystery -------"},
    {"word": "ROME", "clue": "All roads lead to ----"},
    {"word": "POPE", "clue": "The ---- claims the world"},
    {"word": "HOLY", "clue": "The ---- See is a corporation"},
    {"word": "SEE", "clue": "The Holy ---"},
    {"word": "BULL", "clue": "Papal ----"},
    {"word": "UNAM", "clue": "---- Sanctam Trust"},
    {"word": "SANCTAM", "clue": "Unam -------"},
    {"word": "TRUST", "clue": "The Cestui Que -----"},
    {"word": "CESTUI", "clue": "------ Que Vie"},
    {"word": "QUE", "clue": "Cestui --- Vie"},
    {"word": "VIE", "clue": "Cestui Que ---"},
    {"word": "LIFE", "clue": "For the ---- of the survivor"},
    {"word": "DEATH", "clue": "Civil -----"},
    {"word": "CIVIL", "clue": "-----ly dead"},
    {"word": "MORTUS", "clue": "Civiliter ------"},
    {"word": "DEAD", "clue": "The walking ----"},
    {"word": "WALK", "clue": "---- away"},
    {"word": "RUN", "clue": "--- towards truth"},
    {"word": "FLY", "clue": "--- like an eagle"},
    {"word": "EAGLE", "clue": "Idz ill -----"},
    {"word": "BIRD", "clue": "The ---- is free"},
    {"word": "CAGE", "clue": "Open the ----"},
    {"word": "LOCK", "clue": "Pick the ----"},
    {"word": "KEY", "clue": "You hold the ---"},
    {"word": "MASTER", "clue": "You are the ------"},
    {"word": "SLAVE", "clue": "No longer a -----"},
    {"word": "FREE", "clue": "Born ----"},
    {"word": "MAN", "clue": "Hue---"},
    {"word": "WOMAN", "clue": "Womb--"},
    {"word": "CHILD", "clue": "Protect the -----"},
    {"word": "KID", "clue": "Do not --- yourself"},
    {"word": "GOAT", "clue": "Kids are baby ----s"},
    {"word": "SHEEP", "clue": "Do not be -----"},
    {"word": "WOLF", "clue": "---- in sheeps clothing"},
    {"word": "CLOTH", "clue": "Cut from the same -----"},
    {"word": "FABRIC", "clue": "The ------ of reality"},
    {"word": "WEAVE", "clue": "----- a new narrative"},
    {"word": "SPIN", "clue": "---- the truth"},
    {"word": "THREAD", "clue": "Follow the ------"},
    {"word": "NEEDLE", "clue": "Thread the ------"},
    {"word": "HAYSTACK", "clue": "Needle in a --------"},
    {"word": "FIND", "clue": "---- the truth"},
    {"word": "SEEK", "clue": "---- and ye shall find"},
    {"word": "KNOCK", "clue": "----- and it shall open"},
    {"word": "DOOR", "clue": "The ---- is unlocked"},
    {"word": "WALL", "clue": "Tear down the ----"},
    {"word": "BRICK", "clue": "Another ----- in the wall"},
    {"word": "MORTAR", "clue": "Bricks and ------"},
    {"word": "BUILD", "clue": "----- a new world"},
    {"word": "DESTROY", "clue": "------- the old"},
    {"word": "CREATE", "clue": "------ your reality"},
    {"word": "MAKE", "clue": "---- it happen"},
    {"word": "DO", "clue": "-- not try, do"},
    {"word": "TRY", "clue": "There is no ---"},
    {"word": "FAIL", "clue": "To fail is to -----"},
    {"word": "LEARN", "clue": "----- from mistakes"},
    {"word": "GROW", "clue": "---- in wisdom"},
    {"word": "WISE", "clue": "Be ---- as serpents"},
    {"word": "SERPENT", "clue": "The ------- in the garden"},
    {"word": "DOVE", "clue": "Harmless as ----s"},
    {"word": "PEACE", "clue": "----- be with you"},
    {"word": "WAR", "clue": "--- on consciousness"},
    {"word": "FIGHT", "clue": "----- the power"},
    {"word": "POWER", "clue": "Knowledge is -----"},
    {"word": "STRENGTH", "clue": "Unity is --------"},
    {"word": "UNITED", "clue": "------ we stand"},
    {"word": "DIVIDED", "clue": "------- we fall"},
    {"word": "ONE", "clue": "We are ---"},
    {"word": "ALL", "clue": "--- for one"},
    {"word": "MANY", "clue": "The needs of the ----"},
    {"word": "FEW", "clue": "The --- control the many"},
    {"word": "ELITE", "clue": "The global -----"},
    {"word": "CABAL", "clue": "The shadow -----"},
    {"word": "ILLUMINATI", "clue": "The ---------- - the ill ewe'man I.D. / El lumen nazies"},
    {"word": "MASON", "clue": "Free-----"},
    {"word": "LODGE", "clue": "Masonic -----"},
    {"word": "DEGREE", "clue": "33rd ------"},
    {"word": "LEVEL", "clue": "On the -----"},
    {"word": "SQUARE", "clue": "On the ------"},
    {"word": "COMPASS", "clue": "Square and -------"},
    {"word": "GOLD", "clue": "---- standard"},
    {"word": "MONEY", "clue": "Fiat -----"},
    {"word": "CASH", "clue": "Cold hard ----"},
    {"word": "COIN", "clue": "Flip a ----"},
    {"word": "NOTE", "clue": "Federal Reserve ----"},
    {"word": "FEDERAL", "clue": "------- Reserve"},
    {"word": "RESERVE", "clue": "Federal -------"},
    {"word": "SYSTEM", "clue": "The banking ------"},
    {"word": "BANK", "clue": "Central ----"},
    {"word": "CENTRAL", "clue": "------- bank"},
    {"word": "IMF", "clue": "International Monetary ----"},
    {"word": "FUND", "clue": "Monetary ----"},
    {"word": "WORLD", "clue": "----- Bank"},
    {"word": "GLOBAL", "clue": "------ currency"},
    {"word": "CONDUCTOR", "clue": "Be the ---------, not the conned-actor."},
    {"word": "RESET", "clue": "Global -----"},
    {"word": "ORDER", "clue": "New World Hoarders -Jew Hurled -----."},
    {"word": "NEW", "clue": "--- World Order"},
    {"word": "AGENDA", "clue": "------ 21"},
    {"word": "METHINKS", "clue": "-------- the lady doth protest too much."},
    {"word": "PLAN", "clue": "Trust the ----"},
    {"word": "TRUST", "clue": "----- yourself"},
    {"word": "SELF", "clue": "Higher ----"},
    {"word": "HIGHER", "clue": "------ consciousness"},
    {"word": "LEVEL", "clue": "Next -----"},
    {"word": "UP", "clue": "Level --"},
    {"word": "GAME", "clue": "End ----"},
    {"word": "OVER", "clue": "Game ----"},
    {"word": "START", "clue": "----- again"},
    {"word": "BEGIN", "clue": "----- the journey"},
    {"word": "END", "clue": "The --- is near"},
    {"word": "NEAR", "clue": "The time is ----"},
    {"word": "NOW", "clue": "The time is ---"},
    {"word": "HERE", "clue": "Be ---- now"},
    {"word": "THERE", "clue": "Get -----"},
    {"word": "WHERE", "clue": "----- are you"},
    {"word": "WHO", "clue": "--- are you"},
    {"word": "WHAT", "clue": "---- are you"},
    {"word": "WHY", "clue": "--- are you here"},
    {"word": "HOW", "clue": "--- to escape"},
    {"word": "WHEN", "clue": "---- to act"},
    {"word": "ACTION", "clue": "Take ------"},
    {"word": "DO", "clue": "Just -- it"},
    {"word": "IT", "clue": "-- is illegal"},
    {"word": "IS", "clue": "It -- done"},
    {"word": "DONE", "clue": "It is ----"},
    {"word": "FINISH", "clue": "------ the race"},
    {"word": "RACE", "clue": "Rat ----"},
    {"word": "RAT", "clue": "Smell a ---"},
    {"word": "TRAP", "clue": "Mouse ----"},
    {"word": "MOUSE", "clue": "Click the -----"},
    {"word": "CLICK", "clue": "----- here"},
    {"word": "LINK", "clue": "Follow the ----"},
    {"word": "WEB", "clue": "World Wide ---"},
    {"word": "NET", "clue": "Inter---"},
    {"word": "CYBER", "clue": "----- space"},
    {"word": "SPACE", "clue": "Outer -----"},
    {"word": "INNER", "clue": "----- space"},
    {"word": "PEACE", "clue": "Inner -----"},
    {"word": "WAR", "clue": "Inner ---"},
    {"word": "BATTLE", "clue": "The ------ is within"},
    {"word": "WITHIN", "clue": "Look ------"},
    {"word": "WITHOUT", "clue": "As within so -------"},
    {"word": "ABOVE", "clue": "As ----- so below"},
    {"word": "BELOW", "clue": "As above so -----"},
    {"word": "ABLE", "clue": "Abel = ----."}
]

class Game:
    def __init__(self, allow_fullscreen=True):
        # Save previous display state if pygame is already initialized
        self.prev_display_info = None
        try:
            if pygame.get_init():
                # Pygame already initialized - save current display info
                surface = pygame.display.get_surface()
                if surface:
                    # Check if current mode is fullscreen by checking flags
                    flags = surface.get_flags()
                    is_fullscreen = bool(flags & pygame.FULLSCREEN)
                    self.prev_display_info = {
                        'size': surface.get_size(),
                        'caption': pygame.display.get_caption()[0],
                        'is_fullscreen': is_fullscreen,
                        'flags': flags
                    }
        except:
            pass
        
        # Only init if not already initialized
        if not pygame.get_init():
            pygame.init()
        
        # Initialize mixer for sounds
        pygame.mixer.init()
        
        self.width = 1000
        self.height = 700
        self.win = pygame.display.set_mode((self.width, self.height))
        pygame.display.set_caption("Phoenician Phonics Hangman")
        self.clock = pygame.time.Clock()
        
        # Load Safe Fonts
        self.font_intro = pygame.font.Font(None, 80)
        self.font_subtitle = pygame.font.Font(None, 40)
        self.font_clue = pygame.font.Font(None, 30)
        self.font_word = pygame.font.Font(None, 60)
        self.font_ui = pygame.font.Font(None, 36)
        self.font_tiny = pygame.font.Font(None, 24)
        
        # Load sounds
        self.sounds = {}
        try:
            self.sounds['button'] = pygame.mixer.Sound(resource_path('sounds/ui/spacebarbutton.ogg'))
            self.sounds['win'] = pygame.mixer.Sound(resource_path('sounds/easter_eggs/easterunlock.ogg'))
            self.sounds['lose'] = pygame.mixer.Sound(resource_path('sounds/commands/garbage4life_voidabinitio.ogg'))
            self.sounds['error'] = pygame.mixer.Sound(resource_path('sounds/ui/unknowncommanderror_button.ogg'))
            self.sounds['correct'] = pygame.mixer.Sound(resource_path('sounds/ui/phonicswin.ogg'))
            self.sounds['quit'] = pygame.mixer.Sound(resource_path('sounds/ui/gameclose_button.ogg'))
            
            # Set volume levels
            if self.sounds['quit']:
                self.sounds['quit'].set_volume(1.0)  # Full volume for quit sound
            if self.sounds['correct']:
                self.sounds['correct'].set_volume(0.6)  # Lower volume for phonicswin sound
        except Exception as e:
            print(f"Warning: Could not load some sounds: {e}")
            # Create empty sound objects if loading fails
            for key in ['button', 'win', 'lose', 'error', 'correct', 'quit']:
                if key not in self.sounds:
                    self.sounds[key] = None
        
        # Load background music
        self.music_playing = False
        try:
            pygame.mixer.music.load(resource_path('sounds/music/VivaldiFourSeasons.ogg'))
            pygame.mixer.music.set_volume(0.5)  # Set background music volume to 50%
        except Exception as e:
            print(f"Warning: Could not load background music: {e}")
        
        # States
        self.STATE_INTRO = 0
        self.STATE_MENU = 1
        self.STATE_HANGMAN = 2
        self.STATE_GUILLOTINE_INPUT = 3
        self.STATE_GUILLOTINE_ANIM = 4
        self.STATE_GAMEOVER = 5
        
        self.current_state = self.STATE_INTRO
        self.deck = []
        self.current_puzzle = None
        
        # Fullscreen state and control
        self.allow_fullscreen = allow_fullscreen
        self.fullscreen = False
        
        # Sprites
        self.head_sprite = self.create_head_surface(is_dead=False)
        self.dead_head_sprite = self.create_head_surface(is_dead=True)
        
        # Animation timer for game over text
        self.gameover_timer = 0
        
        # Animation timer for header metallic effect
        self.header_animation_timer = 0
        
        # Score counter
        self.score = 0
        
        self.reset_round()

    def create_head_surface(self, is_dead=False):
        radius = 30
        surf = pygame.Surface((radius*2, radius*2), pygame.SRCALPHA)
        
        pygame.draw.circle(surf, FLESH, (radius, radius), radius)
        pygame.draw.circle(surf, BLACK, (radius, radius), radius, 2)
        
        # Phi Symbol
        pygame.draw.line(surf, RED, (radius, 5), (radius, 25), 2)
        pygame.draw.circle(surf, RED, (radius, 12), 6, 1)
        
        if is_dead:
            # X Eyes
            pygame.draw.line(surf, BLACK, (15, 25), (25, 35), 2)
            pygame.draw.line(surf, BLACK, (25, 25), (15, 35), 2)
            pygame.draw.line(surf, BLACK, (35, 25), (45, 35), 2)
            pygame.draw.line(surf, BLACK, (45, 25), (35, 35), 2)
            # Tongue
            pygame.draw.line(surf, BLACK, (20, 45), (40, 45), 2)
            pygame.draw.line(surf, RED, (30, 45), (35, 55), 3)
        else:
            # Eyes
            pygame.draw.circle(surf, WHITE, (20, 30), 6)
            pygame.draw.circle(surf, BLACK, (20, 30), 2)
            pygame.draw.circle(surf, WHITE, (40, 30), 6)
            pygame.draw.circle(surf, BLACK, (40, 30), 2)
            # Mouth
            pygame.draw.circle(surf, BLACK, (30, 48), 5, 2)
        return surf

    def reset_round(self):
        if not self.deck:
            self.deck = FULL_DB[:]
            random.shuffle(self.deck)
        
        self.current_puzzle = self.deck.pop()
        self.guessed_letters = []
        self.mistakes = 0
        self.message = ""
        self.user_text = ""
        
        # Reset all guillotine animation variables completely
        self.blade_y = 150
        self.head_start_x = 735
        self.head_start_y = 420
        self.head_x = self.head_start_x
        self.head_y = self.head_start_y
        self.head_rotation = 0
        self.blood_particles = []
        self.dumpster_x = 675
        self.dumpster_y = 520
    
    def toggle_fullscreen(self):
        if not self.allow_fullscreen:
            return  # Don't allow fullscreen if disabled
        self.fullscreen = not self.fullscreen
        if self.fullscreen:
            self.win = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
            self.width, self.height = self.win.get_size()
        else:
            self.win = pygame.display.set_mode((WIDTH, HEIGHT))
            self.width, self.height = WIDTH, HEIGHT
    
    def cleanup(self):
        """Restore previous display state if it was saved
        
        Returns:
            The restored screen surface, or None if restoration failed
        """
        # Stop background music
        if self.music_playing:
            pygame.mixer.music.stop()
            self.music_playing = False
        
        if self.prev_display_info and self.prev_display_info['size']:
            try:
                # Restore with appropriate flags
                if self.prev_display_info.get('is_fullscreen', False):
                    # Restore fullscreen mode
                    restored_screen = pygame.display.set_mode(
                        self.prev_display_info['size'],
                        pygame.FULLSCREEN | pygame.DOUBLEBUF | pygame.HWSURFACE
                    )
                else:
                    # Restore windowed mode
                    restored_screen = pygame.display.set_mode(
                        self.prev_display_info['size'],
                        pygame.DOUBLEBUF | pygame.HWSURFACE
                    )
                if self.prev_display_info['caption']:
                    pygame.display.set_caption(self.prev_display_info['caption'])
                return restored_screen
            except:
                pass
        return None

    def wrap_text(self, text, color, rect, font):
        # Bulletproof text wrapper to prevent freezing
        rect = pygame.Rect(rect)
        y = rect.top
        lineSpacing = -2
        fontHeight = font.size("Tg")[1]

        while text:
            i = 1
            if y + fontHeight > rect.bottom: break
            
            # Determine how many chars fit on line
            while font.size(text[:i])[0] < rect.width and i < len(text):
                i += 1
            
            # If line is longer than width, split at last space
            if i < len(text): 
                space_index = text.rfind(" ", 0, i)
                if space_index != -1:
                    i = space_index + 1
            
            image = font.render(text[:i], True, color)
            self.win.blit(image, (rect.left, y))
            y += fontHeight + lineSpacing
            
            # CRITICAL FIX: Ensure progress to avoid infinite loop
            if i <= 0: i = 1 
            text = text[i:]

    def draw_animated_metallic_header(self, text, x, y):
        """Draw header text with animated gold metallic shine on the letters themselves"""
        # Get text dimensions
        text_width, text_height = self.font_intro.size(text)
        
        # Draw subtle gradient background behind header area
        bg_surf = pygame.Surface((text_width + 40, text_height + 20), pygame.SRCALPHA)
        bg_x = x - 20
        bg_y = y - 10
        
        # Create subtle gradient from darker to lighter
        for i in range(bg_surf.get_height()):
            ratio = i / bg_surf.get_height()
            # Subtle gradient: dark purple to slightly lighter
            r = int(BG_DARK[0] + (BG_MEDIUM[0] - BG_DARK[0]) * ratio * 0.3)
            g = int(BG_DARK[1] + (BG_MEDIUM[1] - BG_DARK[1]) * ratio * 0.3)
            b = int(BG_DARK[2] + (BG_MEDIUM[2] - BG_DARK[2]) * ratio * 0.3)
            pygame.draw.line(bg_surf, (r, g, b, 150), (0, i), (bg_surf.get_width(), i))
        
        self.win.blit(bg_surf, (bg_x, bg_y))
        
        # Calculate animated position for the shine effect
        time_offset = self.header_animation_timer * 0.02  # Slower animation
        shine_pos = (text_width / 2) + (text_width / 2) * math.sin(time_offset)
        
        # Gold color variations for metallic effect
        bright_gold = (255, 223, 0)    # Bright gold (shine)
        medium_gold = (255, 215, 0)   # Standard gold
        dark_gold = (184, 134, 11)     # Dark gold (shadow areas)
        
        # Render base text in medium gold
        base_text = self.font_intro.render(text, True, medium_gold)
        
        # Create a surface for the shine overlay (same size as text)
        shine_surf = pygame.Surface((text_width, text_height), pygame.SRCALPHA)
        
        # Create horizontal gradient that moves across
        shine_width = text_width * 0.5
        step = max(1, text_width // 100)  # Optimized step size
        
        for i in range(0, text_width, step):
            dist_from_shine = abs(i - shine_pos)
            
            if dist_from_shine < shine_width:
                # Inside shine area - bright gold
                ratio = 1.0 - (dist_from_shine / shine_width)
                # Smooth transition from bright to medium
                r = int(bright_gold[0] * ratio + medium_gold[0] * (1 - ratio))
                g = int(bright_gold[1] * ratio + medium_gold[1] * (1 - ratio))
                b = int(bright_gold[2] * ratio + medium_gold[2] * (1 - ratio))
                alpha = int(255 * ratio * 0.8)  # Fade at edges
            else:
                # Outside shine - no overlay
                r, g, b, alpha = 0, 0, 0, 0
            
            if alpha > 0:
                color = (r, g, b, alpha)
                pygame.draw.line(shine_surf, color, (i, 0), (i, text_height), step)
        
        # Render text in white to use as mask for the shine
        text_mask = self.font_intro.render(text, True, (255, 255, 255))
        
        # Apply shine only where text exists by using the mask
        # Create final surface with base text
        final_surf = pygame.Surface((text_width, text_height), pygame.SRCALPHA)
        final_surf.blit(base_text, (0, 0))
        
        # Apply shine overlay using multiply blend to only affect text pixels
        # First, create a masked version of the shine
        masked_shine = pygame.Surface((text_width, text_height), pygame.SRCALPHA)
        masked_shine.blit(shine_surf, (0, 0))
        # Use the text mask to only show shine on letters
        masked_shine.blit(text_mask, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
        
        # Add the shine to the base text
        final_surf.blit(masked_shine, (0, 0), special_flags=pygame.BLEND_ADD)
        
        self.win.blit(final_surf, (x, y))

    def draw_detailed_hangman(self):
        base_x = 100
        base_y = 450
        # Make gallow brown like guillotine
        pygame.draw.line(self.win, BROWN, (base_x, base_y), (base_x + 200, base_y), 5)
        pygame.draw.line(self.win, BROWN, (base_x + 100, base_y), (base_x + 100, base_y - 250), 5)
        pygame.draw.line(self.win, BROWN, (base_x + 100, base_y - 250), (base_x + 200, base_y - 250), 5)
        pygame.draw.line(self.win, BROWN, (base_x + 200, base_y - 250), (base_x + 200, base_y - 200), 3)

        center_x = base_x + 200
        head_top = base_y - 200
        
        # Head: Show alive head until player loses (mistakes >= 6), then show dead head
        if self.mistakes >= 1: 
            if self.mistakes >= 6:
                # Player lost - show dead head with red marks
                self.win.blit(self.dead_head_sprite, (center_x - 30, head_top))
            else:
                # Player still playing - show alive head
                self.win.blit(self.head_sprite, (center_x - 30, head_top))
        
        # Body parts build up as mistakes increase
        if self.mistakes >= 2: pygame.draw.rect(self.win, SHIRT_COL, (center_x - 20, head_top + 60, 40, 60))
        if self.mistakes >= 3: 
            pygame.draw.line(self.win, FLESH, (center_x - 20, head_top + 70), (center_x - 50, head_top + 100), 10)
            pygame.draw.circle(self.win, FLESH, (center_x - 50, head_top + 100), 8)
        if self.mistakes >= 4: 
            pygame.draw.line(self.win, FLESH, (center_x + 20, head_top + 70), (center_x + 50, head_top + 100), 10)
            pygame.draw.circle(self.win, FLESH, (center_x + 50, head_top + 100), 8)
        if self.mistakes >= 5: 
            pygame.draw.line(self.win, PANT_COL, (center_x - 10, head_top + 120), (center_x - 20, head_top + 170), 12)
            pygame.draw.rect(self.win, BLACK, (center_x - 30, head_top + 170, 20, 10))
        if self.mistakes >= 6: 
            # Final leg - body is complete and hanging
            pygame.draw.line(self.win, PANT_COL, (center_x + 10, head_top + 120), (center_x + 20, head_top + 170), 12)
            pygame.draw.rect(self.win, BLACK, (center_x + 10, head_top + 170, 20, 10))

    def draw_guillotine(self):
        base_x = 700
        base_y = 450
        pygame.draw.rect(self.win, BROWN, (base_x - 60, base_y, 220, 20))
        pygame.draw.rect(self.win, BROWN, (base_x, base_y - 300, 15, 300))
        pygame.draw.rect(self.win, BROWN, (base_x + 90, base_y - 300, 15, 300))
        pygame.draw.rect(self.win, BROWN, (base_x - 10, base_y - 310, 130, 20))
        pygame.draw.polygon(self.win, GRAY, [
            (base_x + 16, self.blade_y),
            (base_x + 89, self.blade_y),
            (base_x + 89, self.blade_y + 50), 
            (base_x + 16, self.blade_y + 25)  
        ])

    def draw_dumpster_front(self):
        pygame.draw.rect(self.win, GREEN, (self.dumpster_x, self.dumpster_y, 160, 100))
        pygame.draw.rect(self.win, DARK_GRAY, (self.dumpster_x-10, self.dumpster_y, 180, 15))
        text_surf = self.font_tiny.render("GARBAGE 4 LIFE", True, WHITE)
        text_surf = pygame.transform.rotate(text_surf, 5)
        self.win.blit(text_surf, (self.dumpster_x + 15, self.dumpster_y + 40))

    def draw_dumpster_back(self):
        pygame.draw.rect(self.win, DARK_GREEN, (self.dumpster_x, self.dumpster_y, 160, 100))
    
    def draw_background(self):
        """Draw detailed background with texture and decorative elements"""
        # First, fill the entire screen with base color to ensure complete clearing
        self.win.fill(BG_DARK)
        
        # Base gradient background
        for y in range(0, self.height, 2):
            ratio = y / self.height
            r = int(BG_DARK[0] + (BG_MEDIUM[0] - BG_DARK[0]) * ratio)
            g = int(BG_DARK[1] + (BG_MEDIUM[1] - BG_DARK[1]) * ratio)
            b = int(BG_DARK[2] + (BG_MEDIUM[2] - BG_DARK[2]) * ratio)
            pygame.draw.line(self.win, (r, g, b), (0, y), (self.width, y))
        
        # Add texture/noise pattern
        for _ in range(200):
            x = random.randint(0, self.width)
            y = random.randint(0, self.height)
            alpha = random.randint(10, 30)
            size = random.randint(1, 3)
            color = (BG_ACCENT[0], BG_ACCENT[1], BG_ACCENT[2], alpha)
            surf = pygame.Surface((size, size), pygame.SRCALPHA)
            surf.fill(color)
            self.win.blit(surf, (x, y))
        
        # Phoenix feather patterns (top corners)
        for i in range(8):
            x = 30 + i * 25
            y = 30 + i * 12
            # Feather shape
            points = [
                (x, y),
                (x + 15, y + 5),
                (x + 25, y + 15),
                (x + 20, y + 25),
                (x + 10, y + 20),
                (x, y + 10)
            ]
            color_intensity = max(50, 200 - i * 20)
            feather_color = (*BG_GOLD, color_intensity)
            feather_surf = pygame.Surface((60, 40), pygame.SRCALPHA)
            # Adjust points relative to surface
            rel_points = [(p[0] - x, p[1] - y) for p in points]
            pygame.draw.polygon(feather_surf, feather_color, rel_points)
            self.win.blit(feather_surf, (x, y))
            # Mirror on right side
            mirror_x = self.width - x - 60
            mirror_surf = pygame.transform.flip(feather_surf, True, False)
            self.win.blit(mirror_surf, (mirror_x, y))
        
        # Decorative corner arcs
        corner_size = 100
        arc_width = 3
        # Top-left
        pygame.draw.arc(self.win, BG_GOLD, (10, 10, corner_size, corner_size), 0, 1.57, arc_width)
        # Top-right
        pygame.draw.arc(self.win, BG_GOLD, (self.width - corner_size - 10, 10, corner_size, corner_size), 1.57, 3.14, arc_width)
        # Bottom-left
        pygame.draw.arc(self.win, BG_GOLD, (10, self.height - corner_size - 10, corner_size, corner_size), -1.57, 0, arc_width)
        # Bottom-right
        pygame.draw.arc(self.win, BG_GOLD, (self.width - corner_size - 10, self.height - corner_size - 10, corner_size, corner_size), 3.14, 4.71, arc_width)
        
        # Horizontal decorative lines with gradient
        for i in range(3):
            y_pos = 120 + i * 180
            line_surf = pygame.Surface((self.width, 2), pygame.SRCALPHA)
            for x in range(0, self.width, 4):
                alpha = int(30 + 20 * abs(math.sin(x / 50.0)))
                color = (*BG_ACCENT, alpha)
                pygame.draw.line(line_surf, color, (x, 0), (x + 2, 0), 1)
            self.win.blit(line_surf, (0, y_pos))
        
        # Vertical accent lines on sides
        left_line_surf = pygame.Surface((2, self.height), pygame.SRCALPHA)
        right_line_surf = pygame.Surface((2, self.height), pygame.SRCALPHA)
        for y in range(0, self.height, 3):
            alpha = int(20 + 15 * abs(math.sin(y / 80.0)))
            line_color = (*BG_ORANGE, alpha)
            pygame.draw.line(left_line_surf, line_color, (0, y), (0, y + 2), 1)
            pygame.draw.line(right_line_surf, line_color, (0, y), (0, y + 2), 1)
        self.win.blit(left_line_surf, (15, 0))
        self.win.blit(right_line_surf, (self.width - 15, 0))
        
        # Central decorative circle pattern (subtle)
        center_x, center_y = self.width // 2, self.height // 2
        for radius in range(50, 300, 50):
            alpha = max(10, 40 - radius // 10)
            circle_surf = pygame.Surface((radius * 2, radius * 2), pygame.SRCALPHA)
            pygame.draw.circle(circle_surf, (*BG_ACCENT, alpha), (radius, radius), radius, 2)
            self.win.blit(circle_surf, (center_x - radius, center_y - radius))

    def run(self):
        running = True
        while running:
            # Draw detailed background
            self.draw_background()
            
            # Update animation timers
            self.header_animation_timer += 1
            
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    # Stop background music before quitting
                    if self.music_playing:
                        pygame.mixer.music.stop()
                        self.music_playing = False
                    return  # Return cleanly instead of quitting
                
                # Fullscreen toggle with F11 (only if allowed)
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_F11 and self.allow_fullscreen:
                        self.toggle_fullscreen()
                
                if self.current_state == self.STATE_INTRO:
                    if event.type == pygame.KEYDOWN or event.type == pygame.MOUSEBUTTONDOWN:
                        if self.sounds['button']:
                            self.sounds['button'].play()
                        self.current_state = self.STATE_MENU
                        # Start background music when entering menu
                        if not self.music_playing:
                            try:
                                pygame.mixer.music.play(-1)  # -1 means loop indefinitely
                                self.music_playing = True
                            except:
                                pass
                
                elif self.current_state == self.STATE_MENU:
                    if event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_s:
                            if self.sounds['button']:
                                self.sounds['button'].play()
                            self.reset_round()
                            self.current_state = self.STATE_HANGMAN
                            # State changed - popup will disappear on next frame
                        if event.key == pygame.K_g:
                            if self.sounds['button']:
                                self.sounds['button'].play()
                            self.reset_round()
                            self.current_state = self.STATE_GUILLOTINE_INPUT
                            # State changed - popup will disappear on next frame
                
                elif self.current_state == self.STATE_HANGMAN:
                    if event.type == pygame.KEYDOWN:
                        if event.unicode.isalpha():
                            guess = event.unicode.upper()
                            if guess not in self.guessed_letters:
                                self.guessed_letters.append(guess)
                                if guess not in self.current_puzzle['word']:
                                    self.mistakes += 1
                                    # Play error sound for incorrect letter
                                    if self.sounds['error']:
                                        self.sounds['error'].play()
                                else:
                                    # Play correct letter sound
                                    if self.sounds['correct']:
                                        self.sounds['correct'].play()
                
                elif self.current_state == self.STATE_GUILLOTINE_INPUT:
                    if event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_RETURN:
                            if self.user_text.upper() == self.current_puzzle['word']:
                                self.message = "YOU DECODED THE PHONICS!"
                                self.score += 10  # 10 points for guillotine win
                                self.gameover_timer = 0
                                # Play win sound
                                if self.sounds['win']:
                                    self.sounds['win'].play()
                                self.current_state = self.STATE_GAMEOVER
                            else:
                                self.message = "WRONG! OFF WITH THEIR HEAD!"
                                # Play lose sound
                                if self.sounds['lose']:
                                    self.sounds['lose'].play()
                                self.current_state = self.STATE_GUILLOTINE_ANIM
                                for _ in range(50):
                                    self.blood_particles.append([
                                        self.head_x + 30, self.head_y + 40,
                                        random.uniform(-4, 4), random.uniform(-10, -2),
                                        random.randint(2, 5)
                                    ])
                        elif event.key == pygame.K_BACKSPACE:
                            self.user_text = self.user_text[:-1]
                        else:
                            if len(self.user_text) < 20 and event.unicode.isalpha():
                                self.user_text += event.unicode.upper()
                                # Play button sound when typing letters
                                if self.sounds['button']:
                                    self.sounds['button'].play()
                
                elif self.current_state == self.STATE_GAMEOVER:
                    if event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_r:
                            # Reset everything when returning to menu
                            if self.sounds['button']:
                                self.sounds['button'].play()
                            self.reset_round()
                            self.current_state = self.STATE_MENU
                        if event.key == pygame.K_q:
                            # Stop background music before quitting
                            if self.music_playing:
                                pygame.mixer.music.stop()
                                self.music_playing = False
                            if self.sounds['quit']:
                                # Play the quit sound and wait for it to finish
                                channel = self.sounds['quit'].play()
                                # Wait for the sound to finish playing
                                if channel:
                                    # Get sound length in seconds, convert to milliseconds
                                    try:
                                        sound_length_seconds = self.sounds['quit'].get_length()
                                        pygame.time.wait(int(sound_length_seconds * 1000) + 100)  # Add 100ms buffer
                                    except:
                                        # Fallback: wait a reasonable amount if get_length fails
                                        pygame.time.wait(500)
                                else:
                                    # Fallback: wait a reasonable amount if channel unavailable
                                    pygame.time.wait(500)
                            return  # Return cleanly to main game

            # --- DRAWING ---
            if self.current_state == self.STATE_INTRO:
                # Title at top center with animated metallic effect
                title_width = self.font_intro.size("PHOENICIAN HANGMAN")[0]
                self.draw_animated_metallic_header("PHOENICIAN HANGMAN", 
                    self.width/2 - title_width/2, 20)
                # Subtitle below title
                sub = self.font_subtitle.render("Press Any Key to Start", True, TEXT_LIGHT)
                self.win.blit(sub, (self.width/2 - sub.get_width()/2, 100))
            
            else:
                # Title at top center (for all states except intro) - draw before panels
                title_width = self.font_intro.size("PHOENICIAN HANGMAN")[0]
                self.draw_animated_metallic_header("PHOENICIAN HANGMAN", 
                    self.width/2 - title_width/2, 20)
                
                # URL text below title, above yellow line
                url_text = self.font_tiny.render("---> https://legalnamefraud.carrd.co <---", True, TEXT_LIGHT)
                self.win.blit(url_text, (self.width/2 - url_text.get_width()/2, 75))
                
                # Layout with semi-transparent panels
                # Yellow line just above PHONIC CLUE text
                pygame.draw.line(self.win, BG_GOLD, (0, 95), (self.width, 95), 2)
                
                # Header panel (below title, starting at y=100 to leave room for title)
                header_surf = pygame.Surface((self.width, 60), pygame.SRCALPHA)
                header_surf.fill((*BG_MEDIUM, 220))
                self.win.blit(header_surf, (0, 100))
                
                # Footer panel
                footer_surf = pygame.Surface((self.width, 100), pygame.SRCALPHA)
                footer_surf.fill((*BG_DARK, 240))
                self.win.blit(footer_surf, (0, self.height-100))
                pygame.draw.line(self.win, BG_GOLD, (0, self.height-100), (self.width, self.height-100), 2)

                # Footer (no menu options in footer anymore - they're in popup)
                if self.current_state != self.STATE_MENU and self.current_state != self.STATE_GAMEOVER:
                    msg = "Type letters to guess." if self.current_state == self.STATE_HANGMAN else "Type full word and press ENTER."
                    info = self.font_tiny.render(msg, True, TEXT_MEDIUM)
                    self.win.blit(info, (self.width/2 - info.get_width()/2, self.height - 60))
                elif self.current_state == self.STATE_GAMEOVER:
                    opt = self.font_ui.render("[R] PLAY AGAIN    [Q] QUIT", True, TEXT_LIGHT)
                    self.win.blit(opt, (self.width/2 - opt.get_width()/2, self.height - 60))

                # Gameplay Area
                if self.current_state == self.STATE_MENU:
                    self.draw_detailed_hangman()
                    self.draw_guillotine()
                    # NO HEAD in menu - head only appears during guillotine animation
                    self.draw_dumpster_front()
                    
                    # Choose Your Fate popup box in middle of screen - ONLY in menu state
                    popup_width = 650
                    popup_height = 220
                    popup_x = self.width/2 - popup_width/2
                    popup_y = self.height/2 - popup_height/2
                    
                    # Popup background - fully opaque
                    popup_surf = pygame.Surface((popup_width, popup_height))
                    popup_surf.fill(BG_DARK)
                    self.win.blit(popup_surf, (popup_x, popup_y))
                    pygame.draw.rect(self.win, BG_GOLD, (popup_x, popup_y, popup_width, popup_height), 3)
                    
                    # Title
                    title_txt = self.font_word.render("CHOOSE YOUR FATE", True, TEXT_GOLD)
                    self.win.blit(title_txt, (popup_x + popup_width/2 - title_txt.get_width()/2, popup_y + 20))
                    
                    # Options - use slightly smaller font to ensure text fits
                    opt1 = self.font_ui.render("[S] START HANGMAN (Letter by Letter)", True, TEXT_LIGHT)
                    opt2 = self.font_ui.render("[G] GUILLOTINE GAMBLE (Full Word Guess)", True, TEXT_LIGHT)
                    
                    # Check if text fits, if not use smaller font
                    if opt2.get_width() > popup_width - 40:  # 40px padding (20px each side)
                        opt1 = self.font_clue.render("[S] START HANGMAN (Letter by Letter)", True, TEXT_LIGHT)
                        opt2 = self.font_clue.render("[G] GUILLOTINE GAMBLE (Full Word Guess)", True, TEXT_LIGHT)
                    
                    self.win.blit(opt1, (popup_x + popup_width/2 - opt1.get_width()/2, popup_y + 85))
                    self.win.blit(opt2, (popup_x + popup_width/2 - opt2.get_width()/2, popup_y + 130))

                elif self.current_state == self.STATE_HANGMAN:
                    self.draw_detailed_hangman()
                    self.draw_guillotine()
                    self.draw_dumpster_front()
                    
                    # Word display in CHOOSE YOUR FATE area (left side, y=550)
                    display_word = "".join([letter if letter in self.guessed_letters else "_" for letter in self.current_puzzle['word']])
                    display_word_spaced = " ".join(display_word)
                    
                    txt = self.font_word.render(display_word_spaced, True, TEXT_GOLD)
                    self.win.blit(txt, (50, 550))
                    
                    # Used letters below the word
                    used = self.font_ui.render("Used: " + " ".join(self.guessed_letters), True, TEXT_RED)
                    self.win.blit(used, (50, 600))
                    
                    if "_" not in display_word:
                        self.message = "YOU DECODED THE PHONICS!"
                        self.score += 5  # 5 points for hangman win
                        self.gameover_timer = 0
                        # Play win sound
                        if self.sounds['win']:
                            self.sounds['win'].play()
                        self.current_state = self.STATE_GAMEOVER
                    if self.mistakes >= 6:
                        self.message = f"HANGED! WORD: {self.current_puzzle['word']}"
                        self.gameover_timer = 0
                        # Play lose sound
                        if self.sounds['lose']:
                            self.sounds['lose'].play()
                        self.current_state = self.STATE_GAMEOVER

                elif self.current_state == self.STATE_GUILLOTINE_INPUT:
                    self.draw_detailed_hangman()
                    self.draw_guillotine()
                    self.win.blit(self.head_sprite, (self.head_start_x, self.head_start_y))
                    self.draw_dumpster_front()
                    
                    prompt = self.font_ui.render("ENTER LITERAL TRANSLATION:", True, TEXT_GOLD)
                    self.win.blit(prompt, (self.width/2 - prompt.get_width()/2, 250))
                    pygame.draw.rect(self.win, BG_GOLD, (self.width/2 - 200, 300, 400, 50), 2)
                    txt = self.font_word.render(self.user_text, True, TEXT_LIGHT)
                    self.win.blit(txt, (self.width/2 - 190, 305))

                elif self.current_state == self.STATE_GUILLOTINE_ANIM:
                    self.draw_detailed_hangman()
                    self.draw_dumpster_back()
                    self.draw_guillotine()
                    
                    if self.blade_y < 390:
                        self.blade_y += 20
                    else:
                        if self.head_y < 550:
                            self.head_y += 12
                            self.head_rotation += 10
                            # Update and draw blood particles
                            for p in self.blood_particles:
                                p[0] += p[2]
                                p[1] += p[3]
                                p[3] += 0.5
                                pygame.draw.circle(self.win, BLOOD_RED, (int(p[0]), int(p[1])), p[4])
                        else:
                            self.message = f"GARBAGE! WORD: {self.current_puzzle['word']}"
                            self.gameover_timer = 0
                            self.current_state = self.STATE_GAMEOVER
                    
                    # Draw head only once per frame at current position
                    rot_head = pygame.transform.rotate(self.head_sprite, self.head_rotation)
                    new_rect = rot_head.get_rect(center=(self.head_x + 30, self.head_y + 30))
                    self.win.blit(rot_head, new_rect.topleft)
                    self.draw_dumpster_front()
                
                # Phonic Clue on left side (just above game screen) - draw after gameplay elements so it appears on top
                # Only show after choosing fate
                if self.current_state != self.STATE_MENU and self.current_state != self.STATE_INTRO and self.current_state != self.STATE_GAMEOVER:
                    header = self.font_ui.render("PHONIC CLUE:", True, TEXT_GOLD)
                    self.win.blit(header, (20, 100))
                    
                    # Wrap text at 65 characters per line to avoid overlapping guillotine
                    clue_text = self.current_puzzle['clue']
                    words = clue_text.split()
                    lines = []
                    current_line = ""
                    
                    for word in words:
                        # Check if adding this word would exceed 65 characters
                        test_line = current_line + (" " if current_line else "") + word
                        if len(test_line) <= 65:
                            current_line = test_line
                        else:
                            if current_line:
                                lines.append(current_line)
                            current_line = word
                    if current_line:
                        lines.append(current_line)
                    
                    # Render each line
                    y_pos = 130
                    line_height = self.font_clue.get_height()
                    for line in lines:
                        if y_pos + line_height > 220:  # Stop before going too far down
                            break
                        line_surf = self.font_clue.render(line, True, TEXT_LIGHT)
                        self.win.blit(line_surf, (20, y_pos))
                        y_pos += line_height

                elif self.current_state == self.STATE_GAMEOVER:
                    # Update animation timer
                    self.gameover_timer += 1
                    
                    # Draw game scene behind the text
                    if "GARBAGE" in self.message:
                        self.draw_dumpster_back()
                        self.draw_guillotine()
                        self.draw_dumpster_front()
                    else:
                        self.draw_detailed_hangman()
                        self.draw_guillotine()
                        self.draw_dumpster_front()
                    
                    # Animated text overlay - no panel, just animated text
                    # Determine color based on win/loss
                    c = TEXT_GREEN if "WIN" in self.message or "DECODED" in self.message else TEXT_RED
                    
                    # Create pulsing animation effect
                    pulse = 1.0 + 0.1 * math.sin(self.gameover_timer * 0.1)
                    base_size = 72
                    animated_size = int(base_size * pulse)
                    
                    # Create font with animated size
                    animated_font = pygame.font.Font(None, animated_size)
                    
                    # Render text with word wrapping if needed
                    words = self.message.split()
                    lines = []
                    current_line = ""
                    max_width = self.width - 100  # Leave 50px margin on each side
                    
                    for word in words:
                        test_line = current_line + (" " if current_line else "") + word
                        test_surf = animated_font.render(test_line, True, c)
                        if test_surf.get_width() <= max_width:
                            current_line = test_line
                        else:
                            if current_line:
                                lines.append(current_line)
                            current_line = word
                    if current_line:
                        lines.append(current_line)
                    
                    # Draw each line centered
                    line_height = animated_font.get_height()
                    total_height = len(lines) * line_height
                    start_y = self.height / 2 - total_height / 2
                    
                    for i, line in enumerate(lines):
                        txt = animated_font.render(line, True, c)
                        x = self.width / 2 - txt.get_width() / 2
                        y = start_y + i * line_height
                        self.win.blit(txt, (x, y))

            # Score display - draw last so it's on top of everything (including guillotine animation)
            if self.current_state != self.STATE_INTRO:
                score_text = self.font_ui.render(f"SCORE: {self.score}", True, TEXT_GOLD)
                score_x = self.width - score_text.get_width() - 45
                self.win.blit(score_text, (score_x, 130))

            pygame.display.update()
            self.clock.tick(FPS)

def run_hangman_game(allow_fullscreen=False):
    """Function to run the hangman game - can be called from other modules
    
    Args:
        allow_fullscreen: If False, disables F11 fullscreen toggle (recommended when integrated)
    
    Returns:
        The restored screen surface, or None if restoration failed
    """
    try:
        game = Game(allow_fullscreen=allow_fullscreen)
        game.run()
        restored_screen = game.cleanup()  # Restore previous display state
        return restored_screen
    except Exception as e:
        print("\n\n--- CRITICAL ERROR IN HANGMAN GAME ---")
        traceback.print_exc()
        print("----------------------\n")
        return None

if __name__ == "__main__":
    try:
        game = Game()
        game.run()
    except Exception as e:
        print("\n\n--- CRITICAL ERROR ---")
        traceback.print_exc()
        print("----------------------\n")
        input("Press Enter to Exit...")